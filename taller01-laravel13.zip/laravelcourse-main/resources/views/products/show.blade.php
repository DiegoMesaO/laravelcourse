@extends('layouts.app')

@section('title', 'Producto #'.$product->id)

@section('content')
    <h1 class="h2 mb-4">Detalle del producto</h1>
    <dl class="row card card-body mb-3">
        <dt class="col-sm-3">ID</dt><dd class="col-sm-9">{{ $product->id }}</dd>
        <dt class="col-sm-3">Nombre</dt><dd class="col-sm-9">{{ $product->name }}</dd>
        <dt class="col-sm-3">Precio</dt><dd class="col-sm-9">{{ $product->price }}</dd>
        <dt class="col-sm-3">Creado</dt><dd class="col-sm-9">{{ $product->created_at }}</dd>
        <dt class="col-sm-3">Actualizado</dt><dd class="col-sm-9">{{ $product->updated_at }}</dd>
    </dl>
    <a class="btn btn-outline-secondary" href="{{ route('products.index') }}">Volver al listado</a>
    <form class="d-inline" method="POST" action="{{ route('products.destroy', $product) }}" onsubmit="return confirm('¿Deseas eliminar este producto?');">
        @csrf
        @method('DELETE')
        <button class="btn btn-danger" type="submit">Eliminar producto</button>
    </form>
@endsection
