@extends('layouts.app')

@section('title', 'Crear producto')

@section('content')
    <h1 class="h2 mb-4">Crear producto</h1>
    <form method="POST" action="{{ route('products.store') }}" class="card card-body">
        @csrf
        <div class="mb-3">
            <label class="form-label" for="name">Nombre</label>
            <input class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name') }}" required maxlength="120">
            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div class="mb-3">
            <label class="form-label" for="price">Precio</label>
            <input class="form-control @error('price') is-invalid @enderror" id="price" name="price" type="number" value="{{ old('price') }}" required min="0" step="1">
            @error('price')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div><button class="btn btn-primary" type="submit">Guardar producto</button></div>
    </form>
@endsection
