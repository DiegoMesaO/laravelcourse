@extends('layouts.app')

@section('title', 'Listado de productos')

@section('content')
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h2 mb-0">Productos</h1>
        <a class="btn btn-primary" href="{{ route('products.create') }}">Crear producto</a>
    </div>

    @if (session('success'))
        <div class="alert alert-success" role="alert">{{ session('success') }}</div>
    @endif

    <table class="table table-striped align-middle">
        <thead><tr><th>ID</th><th>Nombre</th></tr></thead>
        <tbody>
            @forelse ($products as $product)
                <tr>
                    <td><a href="{{ route('products.show', $product) }}">{{ $product->id }}</a></td>
                    <td>{{ $product->name }}</td>
                </tr>
            @empty
                <tr><td colspan="2" class="text-center">No hay productos registrados.</td></tr>
            @endforelse
        </tbody>
    </table>
@endsection
