@extends('layouts.app')

@section('title', 'Taller 01 | Productos')

@section('content')
    <section class="text-center py-5">
        <h1 class="mb-3">Taller 01: Productos</h1>
        <p class="lead mb-4">Selecciona la actividad que deseas realizar.</p>
        <a class="btn btn-primary me-2" href="{{ route('products.create') }}">Crear producto</a>
        <a class="btn btn-outline-primary" href="{{ route('products.index') }}">Listar productos</a>
    </section>
@endsection
