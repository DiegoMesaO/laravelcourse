<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>@yield('title', 'Taller 01')</title>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="{{ route('home') }}">Taller 01</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="{{ route('home') }}">Inicio</a>
                <a class="nav-link" href="{{ route('products.create') }}">Crear producto</a>
                <a class="nav-link" href="{{ route('products.index') }}">Productos</a>
            </div>
        </div>
    </nav>
    <main class="container my-5">@yield('content')</main>
    <footer class="border-top py-3 text-center text-muted">Taller 01 · Laravel 13</footer>
</body>
</html>
