<?php

use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;

Route::view('/', 'home.index')->name('home');

Route::resource('products', ProductController::class)
    ->only(['index', 'create', 'store', 'show', 'destroy']);
